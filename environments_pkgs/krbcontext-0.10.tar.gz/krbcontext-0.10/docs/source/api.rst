API
===

krbcontext.context
------------------

.. autoclass:: krbcontext.context.krbContext
   :members:
   :private-members:
   :special-members: __enter__, __exit__
