.. krbcontext documentation master file, created by
   sphinx-quickstart on Mon Oct  3 18:57:54 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to krbcontext's documentation!
======================================

Contents:

.. image:: https://img.shields.io/pypi/v/krbcontext.svg
   :alt: PyPI
   :target: https://pypi.org/project/krbcontext/

.. image:: https://img.shields.io/pypi/pyversions/krbcontext.svg
   :alt: PyPI - Python Version
   :target: https://pypi.org/project/krbcontext/

.. image:: https://travis-ci.org/krbcontext/python-krbcontext.svg?branch=master
   :target: https://travis-ci.org/krbcontext/python-krbcontext

.. image:: https://codecov.io/gh/krbcontext/python-krbcontext/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/krbcontext/python-krbcontext

.. toctree::
   :maxdepth: 2

   usage
   api
   release-notes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

